package com.example.covidapps.adapter;

public class UserAdapter {
}
